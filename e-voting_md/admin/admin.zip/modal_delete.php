<!-- Delete Item Modal -->
<div class="modal fade" id="modal-delete">
	<div class="modal-dialog">
	  <div class="modal-content modal-view modal-pad60 text-center lead blue-color">
		<p class="mbot30">
			Are you sure you want to delete the item now ?
		</p>
		<a href="#" class="btn btn-danger" id="delete-item">
			YES
		</a>
		<button class="btn btn-primary" data-dismiss="modal" aria-hidden="true">
			NO
		</button>
	  </div>
	</div>
</div>