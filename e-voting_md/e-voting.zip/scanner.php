
<!-- DEVELOPED BY WEB ROBO -->

<!-- structure of php -->

<!Doctype>

<html>
		
	<head>
	
		<title>WEB ROBO</title>
		<link href="style.css" rel="stylesheet" type="text/css" />
		<script src="jquery1.9.1.js" rel="javascript" type="text/javascript">
	</script>
	<style>
		#welcome{
			width	:	450px;
			height	:	250px;
			background	:	#0FA1F2;
			margin	:	0 auto;
			border-radius	:	8px;
			padding-top	:	4px;
		}
		#welcome h2,h4{
			color		:	white;
		}
		h4{
			margin-left		:	18px;
		}
	</style>
	
</head>
<body>
		
		<!-- wrapper starts-->
		<div id="wrapper">			
			
			<div id="header">	
				<h1>WEBSITE SECURITY USING DATA HIDING IN QR CODE</h1>
			</div>
			
			<div id="menu">		
				<ul>					
					<li> <a href="welcome.php">Profile</a>  </li>			
					<li> <a href="index2.php">QR Code Generator</a>  </li>			
					<li> <a href="decode.php">QR Reader</a>  </li>	
					<li> <a href="scanner.php" class="active">QR Scanner</a>  </li>	
					<li> <a href="index.php">LOGOUT</a></li>			
				</ul>
			</div>
		
			<div id="content">	
					<h2>QR Code Scanner </h2>
<body>
	<?php
		include_once('auth.php');
	?>
	<div id="welcome">
		<center>
			<h4>Under Construction</h4>
		</center>
	</div>
</div>
			
			<div id="footer">			
			</div>
			
		</div>
		<!-- wrapper ends-->
	
	</body>
	</html>